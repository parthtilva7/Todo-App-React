import { View, Text, Button, Switch, Alert } from "react-native";
import { Pressable, Modal, SafeAreaView } from "react-native";
import React, { useState } from "react";
import styles from "./styles";
export default function Task(props) {
  const [showModal, setShowModal] = useState(false);
  const handleModalToggle = () => {
    setShowModal(!showModal);
  };
  const handleStatusChangePress = () => {
    props.onStatusChange(props.task.id);
  };
  const handleRemovePress = () => {
    Alert.alert(
      "Remove Task",
      "This action will permanently delete this task. This action cannot be undone!",
      [
        {
          text: "Confirm",
          onPress: () => {
            props.onTaskRemoval(props.task.id);
            setShowModal(false);
          },
        },
        {
          text: "Cancel",
        },
      ]
    );
  };

  return (
    <>
      <Pressable onPress={handleModalToggle}>
        <View style={styles.container}>
          <Text style={styles.title}>{props.task.description}</Text>
          <Text style={styles.text}>Id: {props.task.id}</Text>
          <Text style={styles.text}>
            Status: {props.task.done ? "Completed" : "Open"}
          </Text>
        </View>
      </Pressable>
      <Modal visible={showModal}>
        <SafeAreaView style={{ flex: 1 }}>
          <View style={{ backgroundColor: "#8fe5f2" }}>
            <Text style={{ marginLeft: 350 }}>
              <Button onPress={handleModalToggle} title="X" color="#FF0000" />
            </Text>
            <Text style={styles.title}>{props.task.description}</Text>
            <Pressable onPress={handleModalToggle}></Pressable>
            <Switch
              style={{ marginLeft: 165 }}
              value={props.task.done}
              onValueChange={handleStatusChangePress}
            />
            <Text style={{ marginLeft: 150 }}>Toggle Status</Text>
            <Pressable onPress={handleRemovePress}>
              <Text style={styles.removeText}>Delete</Text>
            </Pressable>
          </View>
        </SafeAreaView>
      </Modal>
    </>
  );
}
