import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
  container: {
    marginVertical: 2,
    alignSelf: "stretch",
    backgroundColor: "#8fe5f2",
    fontWeight: "bolder",
    margin: 10,
    padding: 10,
    borderRadius: 7,
    borderWidth: 1,
    borderColor: "#52b4fa",
  },
  title: {
    marginBottom: 10,
    textAlign: "center",
    fontSize: 20,
    color: "blue",
  },
  removeText: {
    margin: 20,
    textAlign: "center",
    fontSize: 15,
    color: "red",
  },
  switchStyle: {
    textAlign: "center",
  },
});

export default styles;
