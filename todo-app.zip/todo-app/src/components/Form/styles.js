import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
  container: {
    alignSelf: "stretch",
    backgroundColor: "#caf8fa",
    padding: 10,
  },
});

export default styles;
