import { View, Text,SafeAreaView } from 'react-native';
import { FontAwesome5 } from '@expo/vector-icons';
import styles from './styles';
import React from 'react';
export default function Header() {
return (
<View style ={styles.container}>
<FontAwesome5 name="grid-horizontal" size={40} />
<SafeAreaView style={styles.container}>
      <Text style={styles.text}>Todo App</Text>
      <Text> by Parth Tilva</Text>
    </SafeAreaView>
</View>
);
}